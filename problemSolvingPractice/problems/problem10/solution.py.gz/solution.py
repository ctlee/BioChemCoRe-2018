import os

#
# It's absolutely essential to test your code and look at some of
# the commands before you put them into an os.system() loop.
# It's easy for looped os.system commands to cause LOTS of trouble
# (accidentally overwriting files you liked, bringing down the whole
# lab file system, etc). A general rule is to leave os.system commands
# to NOT RUN by default so you don't come back in a few months and ruin
# everything before you check that the code still works in the context
# you're about to run it in
#


for i in range(0, 15001, 50):
    command = 'cp origFiles/frame%i.pdb newFiles/frame%07i.pdb' %(i, i*3.5)
    #
    # WHEN THIS IS SET TO "if 1" THE PROGRAM IS INACTIVE.
    # CHANGE TO "if 0" TO ACTIVATE
    #
    if 1:
        print 'Program hardcoded to be inactive - change code to activate'
        print command
    else:
        os.system(command)
