my_number = 1
my_number = my_number * 7

if my_number > 10:
    print "It's bigger than 10!"
else:
    print "It's smaller than or equal to 10 ):"

print 'If it got this far, the program works. Congratulations!'
