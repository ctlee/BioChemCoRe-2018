import numpy
import pylab
import re
import sys

#This only seems really big because of all the comments


#Grab the name of the user's input file
filename = sys.argv[1]

#Get an open-file object for the file
file_object = open(filename)

#Read the data into a list of lines
data_lines = file_object.readlines()



reading_energy_line = False
#I'll set this to true when we pass a line containing "Potential", and it will mean that a value for the potential energy is on the next line


reading_step_line = False
#Same as above, for knowing when to be ready to record a step number


this_step = 0
#I have to keep track of the steps myself. For some reason a couple of these steps don't have energy output. Ah, real data...

python_list_data = []
#Here's where I'll leave entries as I find step and energy pairs. It's a python list, which is good because I can keep appending stuff onto it.

#Iterate through all the lines in the file
for line in data_lines:
    # If the last line we passed was an iteration header...
    if reading_step_line == True:
        # Split this line at all whitespace and take the first entry (that's the step number)
        this_step = int(line.split()[0])
        reading_step_line = False
    #There's a lot of random junk above and below the energy iterations, so I'm going to check for three keywords in the line to ensure that it's really a iteration header line.
    if "Step" in line and "Time" in line and "Lambda" in line:
        reading_step_line = True

    #And following the same logic as above...
    if reading_energy_line == True:
        #Potential energy is in the second column
        this_energy = float(line.split()[1])
        #I'll add the data onto the growing list here
        python_list_data.append([this_step, this_energy])
        reading_energy_line = False

    if "Potential" in line and "Pressure" in line and "Coulomb" in line and "Constr. rmsd" in line:
        reading_energy_line = True
    
# Now I'll convert the python style data to a numpy array
numpy_style_data = numpy.array(python_list_data)


#And then use pylab to plot it!
pylab.plot(numpy_style_data[:,0], numpy_style_data[:,1])
pylab.show()
